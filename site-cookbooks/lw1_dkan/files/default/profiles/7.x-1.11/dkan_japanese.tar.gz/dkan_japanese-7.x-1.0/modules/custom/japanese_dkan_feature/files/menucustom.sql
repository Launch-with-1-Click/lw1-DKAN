update menu_custom set i18n_mode=5 where menu_name='main-menu';
