# Profile ANNAI DKAN

This profile inherits from DKAN and it add some settings for a more Japanese
experience.

## Installation

### AMIAGE DKAN

This is meant to be placed within the AMIAGE DKAN Ec2 on the same directory
where DKAN can be found. Which is /usr/local/src/. Git clone, don't forget
the submodules
```
git clone
cd dkan_japanese
git submodule init
git submodule update
```
Once made this, execute its
drush make `drush make --prepare-install dkan_japanese.make /var/www/html`.

This make file is copying the files, that's is why all the modules should be
there beforehand.

### Standalone

Alternatively, you just need this make file `dkan_japanese-standalone.make` to
get the Drupal with the parent profile, this profile and all the required Drupal
with patches et all.
```
drush make --prepare-install dkan_japanese-standalone.make /var/www/html
```
